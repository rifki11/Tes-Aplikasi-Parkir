create table Jenis_Kendaraan (
ID int identity,
Kode_Kendaraan	varchar(10),
Nama_Kendaraan varchar(250),
Cre_Date		datetime,
Cre_By			varchar(50),
Mod_Date		datetime,
Mod_By			varchar(50)
)

insert into Jenis_Kendaraan
select 'A1','Motor',getdate(),'System',null,''
union all select 'B1','Mobil Penumpang',getdate(),'System',null,''
union all select 'B2','Mobil Barang',getdate(),'System',null,''

create table Tarif_Parkir (
ID int identity,
Kendaraan_ID	int,
tarif_Perjam	decimal(18,2),
tarif_Maksimal	decimal(18,2),
Cre_Date		datetime,
Cre_By			varchar(50),
Mod_Date		datetime,
Mod_By			varchar(50)
)

insert into Tarif_Parkir
select 1,1000,3000,getdate(),'System',null,''
union all select 2,2000,6000,getdate(),'System',null,''
union all select 3,3000,9000,getdate(),'System',null,''

create table Parkir_Min_Jam (
ID int identity,
Min_Menit	int,
Cre_Date		datetime,
Cre_By			varchar(50),
Mod_Date		datetime,
Mod_By			varchar(50)
)

insert into Parkir_Min_Jam select 10,getdate(),'System',null,''

create table Biaya_Parkir_Max (
ID int identity,
Kendaraan_ID	int,
Harga		decimal(18,2),
Cre_Date		datetime,
Cre_By			varchar(50),
Mod_Date		datetime,
Mod_By			varchar(50)
)


insert into Biaya_Parkir_Max
select 1,3000,getdate(),'System',null,''
union all select 2,getdate(),'System',null,''
union all select 3,getdate(),'System',null,''

create table Parkir_Transaksi (
ID int identity,
Nomor_Parkir	varchar(100),
Kendaraan_ID	int,
Nomor_Kendaraan	varchar(25),
Petugas_Pintu_Masuk	varchar(50),
Tanggal_Transaksi_Masuk	datetime,
Tanggal_Masuk	date,
Jam_Masuk		Time,
Petugas_Pintu_Keluar	varchar(50),
Tanggal_Transaksi_Keluar	datetime,
Tanggal_Keluar	date,
Jam_Keluar		Time,
Durasi_Parkir		varchar(10),
Durasi_Description	varchar(250),
Tarif_Parkir		decimal(18,2),
Status_Parkir		varchar(100),
Cre_Date		datetime,
Cre_By			varchar(50),
Mod_Date		datetime,
Mod_By			varchar(50)
)


create table SysUserLogin (
ID	int identity,
Username	varchar(100),
Password	varchar(100),
IsActive	bit,
Cre_Date		datetime,
Cre_By			varchar(50),
Mod_Date		datetime,
Mod_By			varchar(50)

)

insert into SysUserLogin
select 'Admin', 'Admin123456',1,getdate(), 'System','',''


select * from Jenis_Kendaraan
select * from Tarif_Parkir
select * from Biaya_Parkir_Max
select * from Parkir_Min_Jam
select * from Parkir_Transaksi


/*
drop table Jenis_Kendaraan
drop table Tarif_Parkir
drop table Biaya_Parkir_Max
drop table Parkir_Min_Jam
drop table Parkir_Transaksi
*/